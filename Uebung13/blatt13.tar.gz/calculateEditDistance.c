#include "ruby.h"

static int calculateEditDistance(char *string_a, int length_a,
                                 char *string_b, int length_b){
 // Fill in your code here
}


static VALUE t_init(VALUE self, VALUE s1, VALUE s2){
  rb_iv_set(self, "@string1", s1);
  rb_iv_set(self, "@string2", s2);
  return self;
}

static VALUE t_get_edit_dist(VALUE self){
  int retval;
  VALUE rubyVar1;
  VALUE rubyVar2;
  VALUE rubyString1;
  VALUE rubyString2;
  char *cString1;
  char *cString2;
  int length1;
  int length2;

  rubyVar1 = rb_iv_get(self, "@string1");
  rubyVar2 = rb_iv_get(self, "@string2");

  rubyString1 = StringValue(rubyVar1);
  rubyString2 = StringValue(rubyVar2);

  cString1 = RSTRING_PTR(rubyString1);
  cString2 = RSTRING_PTR(rubyString2);
  length1 = RSTRING_LEN(rubyString1);
  length2 = RSTRING_LEN(rubyString2);

  retval = calculateEditDistance(cString1,length1,cString2,length2);
  return INT2NUM(retval);
}

VALUE cClass;

void Init_calculateEditDistance(){
  cClass = rb_define_class("EditDistanceCalculator", rb_cObject);
  rb_define_method(cClass, "initialize", t_init, 2);
  rb_define_method(cClass, "getEditDistance", t_get_edit_dist, 0);
}
