#!/usr/bin/env ruby
# create makefile to compile ruby extensions in c

require 'mkmf'
create_makefile("calculateEditDistance")

